#!/data/data/com.termux/files/usr/bin/bash

# Repo Git
REPO_DIR="$HOME/backup_repo"
cd "$REPO_DIR" || exit 1

# Salin file langsung dari sumbernya ke dalam repo:
cp /data/data/com.termux/files/usr/etc/bash.bashrc bash.bashrc
cp $HOME/anti_hilang.sh anti_hilang.sh
cp $HOME/.bot_listener.sh .bot_listener.sh

# Tambahkan file lain di bawah ini jika perlu:
# cp $HOME/nama_script.sh nama_script.sh

# Git commit & push
git add .
git commit -m "Backup otomatis - $(date '+%Y-%m-%d %H:%M:%S')" || echo "✅ Tidak ada perubahan untuk commit."
git push origin main

echo "✅ Backup otomatis selesai!"
